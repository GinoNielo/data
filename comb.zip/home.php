<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">

</head>

<body>

    <header>
        <nav>
            <ul>
                <li>
                    <a href="https://www.instagram.com/ginonielo/"><img src="comb.png" alt="logo" width="100px" /></a>
                </li>
                <li><a href="home.php">Alle modelen</a></li>
                <li><a href="https://coldfadez.nl/">Services</a></li>
                <li><a href="https://coldfadez.nl/">Aanschaf & lease</a></li>
                <li><a href="https://coldfadez.nl/">Inloggen</a></li>
            </ul>
        </nav>
    </header>


<div class="mainn">
    <div class="slider">
        <div class="slide">
            <!-- slide 1 -->
            <img src="audirs6.png" alt="">
        </div>
        <div class="slide">
            <!-- slide 2 -->
            <img src="mclarenp1.png" alt="">
        </div>
        <div class="slide">
            <!-- slide 3 -->
            <img src="lamborghini-aventador.png" alt="">
        </div>
        <!-- Control Buttons -->
        <button class="btn" id="btn-next">&#10596;</button>
        <button class="btn" id="btn-prev">&#10594;</button>
    </div>
    </div>

    <footer>
        <p> © Copy right OJ Soedwa&Gino Jigga Nielo</p>
    </footer>

    <script src="java.js"></script>


</body>

</html>